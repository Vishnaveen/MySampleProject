package ContinuousIntegrationLearning.CILearning;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import automationprecondition.AppConfig;
import automationprecondition.ExtentReport;
import automationprecondition.TestBase;

public class PageLoadingVerification_1 extends WebPageInitization{

public static String ActualTitle ;

	@Test
	public static void  FirstTestProject_Case() throws IOException {
	TestBase.loadPropertiesFile();
	TestBase.driver.navigate().to(AppConfig.getURL());
	TestBase.driver.manage().deleteAllCookies();
	ActualTitle = TestBase.driver.getCurrentUrl();
	String ExpectedTitle=AppConfig.getURL();
	System.out.println(ActualTitle);
	System.out.println("test passed");
	Assert.assertEquals(ExpectedTitle, ActualTitle);
	TestBase TB=new TestBase();
	String Screen = TB.getScreenShot("");
	if(ActualTitle.contains("BasicCalculator")) {
		ExtentReport.test.log(LogStatus.PASS, "Page Loaded Successfully"+ExtentReport.test.addScreenCapture(Screen));
	}else {
		ExtentReport.test.log(LogStatus.FAIL, "Page Not Loaded Successfully"+ExtentReport.test.addScreenCapture(Screen));
	}
	}

}
