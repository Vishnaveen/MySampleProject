package ContinuousIntegrationLearning.CILearning;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.relevantcodes.extentreports.LogStatus;

import automationprecondition.AppConfig;
import automationprecondition.TestBase;
import automationprecondition.WaitHelper;
import automationprecondition.ExtentReport;

public class WebPageInitization {
	@BeforeClass(alwaysRun=true)
	public void setUp() throws InterruptedException, NullPointerException, IOException
	{
		System.out.println("*****************************************************");
		System.out.println("launching Browser");
		TestBase.getBrowser();
		WaitHelper.setImplicitWait(50);
		WaitHelper.setPageLoadTimeout(50);
	}
	@BeforeTest
	public void testStart() throws IOException
	{			   
		ExtentReport.extent.addSystemInfo("Project Name","Project");
		ExtentReport.extent.addSystemInfo("Time Zone", System.getProperty("user.timezone"));
		ExtentReport.extent.addSystemInfo("User Location", System.getProperty("user.country"));
		ExtentReport.extent.addSystemInfo("Java Version", System.getProperty("java.version"));
	}
	
	@BeforeMethod
	public static void beforeMethod(Method result)
	{
		ExtentReport.test=ExtentReport.extent.startTest(result.getName());
		ExtentReport.test.log(LogStatus.INFO,result.getName()+" Test has Started");
		System.out.println(result.getName()+"Before Method");
	}
	
	@AfterMethod
	public static void afterMethod(ITestResult result) throws IOException
	{
		ExtentReport report = new ExtentReport();
		report.getResult(result);
		System.out.println(result.getName()+" After Method");
		ExtentReport.test.log(LogStatus.INFO,"Current Testing URL is: "+TestBase.driver.getCurrentUrl());
	}
	
	@AfterTest
	public void testResult()
	{
		ExtentReport.extent.endTest(ExtentReport.test);
		ExtentReport.extent.flush();	
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() throws Exception
	{
		if(TestBase.driver!=null)
				{
					System.out.println("Closing the Browser");
					System.out.println("*****************************************************");
					TestBase.driver.quit();
				}
	}	
}
