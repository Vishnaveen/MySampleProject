package ContinuousIntegrationLearning.CILearning;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import automationprecondition.AppConfig;
import automationprecondition.ExtentReport;
import automationprecondition.TestBase;
import automationprecondition.WaitHelper;

public class FunctionalityVerification_2 extends WebPageInitization {
	@Test
	public static void  SecondJavaProject_Case() throws Exception {
		TestBase.loadPropertiesFile();
		TestBase.driver.navigate().to(AppConfig.getURL());
		TestBase.driver.manage().deleteAllCookies();
		String ActualTitle = TestBase.driver.getCurrentUrl();
		String ExpectedTitle=AppConfig.getURL();
		System.out.println(ActualTitle);
		System.out.println("test passed");
		Assert.assertEquals(ExpectedTitle, ActualTitle);
		 WaitHelper.setPageLoadTimeout(60);
//Verifying Add Functionality		 
		 //waitForElement
		 JavascriptExecutor jse = (JavascriptExecutor)TestBase.driver;
		 jse.executeScript("window.scrollBy(0,1000)");
		 WebElement ClearButton =TestBase.getWebElement("FirstNumberEntry");
		 WaitHelper.waitForElement(ClearButton, 100);
		 TestBase.getWebElement("FirstNumberEntry").sendKeys(AppConfig.getFirstnumber());
		 TestBase.getWebElement("SecondNumberEntry").sendKeys(AppConfig.getSecondNumber());
		 int Firstvalue =Integer.parseInt(AppConfig.getFirstnumber());
		 int Secondvalue =Integer.parseInt(AppConfig.getSecondNumber());
		 int Add=Firstvalue+Secondvalue;
		 System.out.println(Add);
		 Select operation;
		 operation = new Select(TestBase.getWebElement("OperationDropDown"));
		 operation.selectByVisibleText("Add");
		 TestBase.getWebElement("CalculatorButton").click();
		 WaitHelper.setImplicitWait(30);
		 WebElement value=TestBase.getWebElement("AnswerField");
		 WaitHelper.waitForElementVisible(value, 90, 10);
		 String ValueDisplayed=value.getAttribute("value");
		 System.out.println(ValueDisplayed);
		 int intValueDisplayed=Integer.parseInt(ValueDisplayed);
		 System.out.println(intValueDisplayed);
		 ExtentReport.test.log(LogStatus.INFO,"Verifying Add Functionality"); 
		 TestBase TB=new TestBase();
		 String Screen = TB.getScreenShot("");
		 //For both positive and Negative Cases - Screensot will be taken
		 if(Add==intValueDisplayed) {
			 ExtentReport.test.log(LogStatus.PASS, "Add Functionality Working Properly"+ExtentReport.test.addScreenCapture(Screen));
		 }else {
			 ExtentReport.test.log(LogStatus.FAIL, "Add Functionality Not Working Properly"+ExtentReport.test.addScreenCapture(Screen));
	     }
		 //Assertion by comparing 
		 Assert.assertEquals(intValueDisplayed, Add);
		 
//Verifying Subtract Functionality	
		 TestBase.getWebElement("ClearButton").click();
		 int Sub=Firstvalue-Secondvalue;
		 System.out.println(Sub);
		 Select operation1;
		 operation1 = new Select(TestBase.getWebElement("OperationDropDown"));
		 operation1.selectByVisibleText("Subtract");
		 TestBase.getWebElement("CalculatorButton").click();
		 WaitHelper.setImplicitWait(30);
		 WebElement Subvalue=TestBase.getWebElement("AnswerField");
		 WaitHelper.waitForElementVisible(Subvalue, 90, 10);
		 String SubvalueDisplayed=Subvalue.getAttribute("value");
		 System.out.println(SubvalueDisplayed);
		 int intSubvalueDisplayed=Integer.parseInt(SubvalueDisplayed);
		 System.out.println(intSubvalueDisplayed);
		 ExtentReport.test.log(LogStatus.INFO,"Verifying Subtract Functionality"); 
		 String Screen1 = TB.getScreenShot("");
		 if(Sub==intSubvalueDisplayed) {
			 ExtentReport.test.log(LogStatus.PASS, "Subtract Functionality Working Properly"+ExtentReport.test.addScreenCapture(Screen1));
		 }else {
			 ExtentReport.test.log(LogStatus.FAIL, "Subtract Functionality Not Working Properly"+ExtentReport.test.addScreenCapture(Screen1));
	     }
		 Assert.assertEquals(intSubvalueDisplayed, Sub);
		 
//Verifying Multiply Functionality	
		 TestBase.getWebElement("ClearButton").click();
		 int Multiply=Firstvalue*Secondvalue;
		 System.out.println(Multiply);
		 Select operation3;
		 operation3 = new Select(TestBase.getWebElement("OperationDropDown"));
		 operation3.selectByVisibleText("Multiply");
		 TestBase.getWebElement("CalculatorButton").click();
		 WaitHelper.setImplicitWait(30);
		 WebElement Multiplyvalue=TestBase.getWebElement("AnswerField");
		 WaitHelper.waitForElementVisible(Multiplyvalue, 90, 10);
		 String MultiplyvalueDisplayed=Subvalue.getAttribute("value");
		 System.out.println(MultiplyvalueDisplayed);
		 int intMultiplyvalueDisplayed=Integer.parseInt(MultiplyvalueDisplayed);
		 System.out.println(intMultiplyvalueDisplayed);
		 ExtentReport.test.log(LogStatus.INFO,"Verifying Multiply Functionality"); 
		 String Screen2 = TB.getScreenShot("");
		 if(Multiply==intMultiplyvalueDisplayed) {
			 ExtentReport.test.log(LogStatus.PASS, "Multiply Functionality Working Properly"+ExtentReport.test.addScreenCapture(Screen2));
		 }else {
			 ExtentReport.test.log(LogStatus.FAIL, "Multiply Functionality Not Working Properly"+ExtentReport.test.addScreenCapture(Screen2));
	     }	 
		 Assert.assertEquals(intMultiplyvalueDisplayed, Multiply);
		 
//Verifying Divide Functionality	
		 TestBase.getWebElement("ClearButton").click();
		 int Divide=Firstvalue/Secondvalue;
		 System.out.println(Divide);
		 Select operation4;
		 operation4 = new Select(TestBase.getWebElement("OperationDropDown"));
		 operation4.selectByVisibleText("Divide");
		 TestBase.getWebElement("CalculatorButton").click();
		 WaitHelper.setImplicitWait(30);
		 WebElement Dividevalue=TestBase.getWebElement("AnswerField");
		 WaitHelper.waitForElementVisible(Dividevalue, 90, 10);
		 String DividevalueDisplayed=Subvalue.getAttribute("value");
		 System.out.println(DividevalueDisplayed);
		 int intDividevalueDisplayed=Integer.parseInt(DividevalueDisplayed);
		 System.out.println(intDividevalueDisplayed);
		 ExtentReport.test.log(LogStatus.INFO,"Verifying Divide Functionality"); 
		 String Screen3 = TB.getScreenShot("");
		 if(Divide==intDividevalueDisplayed) {
			 ExtentReport.test.log(LogStatus.PASS, "Divide Functionality Working Properly"+ExtentReport.test.addScreenCapture(Screen3));
		 }else {
			 ExtentReport.test.log(LogStatus.FAIL, "Divide Functionality Not Working Properly"+ExtentReport.test.addScreenCapture(Screen3));
	     }	 		 
		 Assert.assertEquals(intDividevalueDisplayed, Divide);
	}

}	
