package ContinuousIntegrationLearning.CILearning;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import automationprecondition.AppConfig;
import automationprecondition.ExtentReport;
import automationprecondition.TestBase;
import automationprecondition.WaitHelper;

public class PageElementRedirectionVerification_3 extends WebPageInitization {
	public static String ActualTitle ;
	@Test
	public static void  ThridJavaCase_Case() throws Exception {
		TestBase.loadPropertiesFile();
		TestBase.driver.navigate().to(AppConfig.getURL());
		TestBase.driver.manage().deleteAllCookies();
		ActualTitle = TestBase.driver.getCurrentUrl();
		String ExpectedTitle=AppConfig.getURL();
		System.out.println(ActualTitle);
		System.out.println("test passed");
		Assert.assertEquals(ExpectedTitle, ActualTitle);
//THE NUMBER GUESSING GAME		
		ExtentReport.test.log(LogStatus.INFO, "Landing to NumberGame");
		TestBase.getWebElement("NumberGameElement").click();
		WaitHelper.setImplicitWait(60);
		WebElement NumberGameText= TestBase.getWebElement("NumberGuessGameText");
		String sNumberGameText=NumberGameText.getText();
		System.out.println(sNumberGameText);
		TestBase TB=new TestBase();
		String Screen = TB.getScreenShot("");
		ExtentReport.test.log(LogStatus.INFO, "Landing to NumberGame Page");
		if(sNumberGameText.contains("THE NUMBER GUESSING GAME")) {
			ExtentReport.test.log(LogStatus.PASS, "NumberGame Page Loaded Successfully"+ExtentReport.test.addScreenCapture(Screen));
		}else {
			ExtentReport.test.log(LogStatus.FAIL, "NumberGame Page Not Loaded Successfully"+ExtentReport.test.addScreenCapture(Screen));
		}

		List<WebElement> multipleelement =TestBase.getWebElements("AllNumberGame");
		System.out.println(multipleelement.size());
		for(WebElement e : multipleelement) {
		  System.out.println(e.getText());
		 ExtentReport.test.log(LogStatus.PASS,e.getText());
		}
		
//AutomationKataElement		
		ExtentReport.test.log(LogStatus.INFO, "Landing to Automation Kata");
		TestBase.getWebElement("AutomationKataElement").click();
		WaitHelper.setImplicitWait(60);
		WebElement AutomationKataText= TestBase.getWebElement("AutomationKataText");
		String sAutomationKataText=AutomationKataText.getText();
		System.out.println(sAutomationKataText);
		TestBase TB1=new TestBase();
		String Screen1 = TB1.getScreenShot("");
		if(sAutomationKataText.contains("TEST AUTOMATION KATA")) {
			ExtentReport.test.log(LogStatus.PASS, "Automation Kata Page Loaded Successfully"+ExtentReport.test.addScreenCapture(Screen1));
		}else {
			ExtentReport.test.log(LogStatus.FAIL, "Automation Kata Page not Loaded Successfully"+ExtentReport.test.addScreenCapture(Screen1));
		}
		List<WebElement> multipleelement1 =TestBase.getWebElements("AllAutomationKataText");
		System.out.println(multipleelement1.size());
		for(WebElement e : multipleelement1) {
		  System.out.println(e.getText());
		  ExtentReport.test.log(LogStatus.PASS,e.getText());
		}
//Workshops		
		ExtentReport.test.log(LogStatus.INFO, "Landing to Workshops");
		TestBase.getWebElement("WorkshopsElement").click();
		WaitHelper.setImplicitWait(60);
		WebElement WorkshopsText= TestBase.getWebElement("WorkshopsText");
		String sWorkshopsText=WorkshopsText.getText();
		System.out.println(sWorkshopsText);
		TestBase TB2=new TestBase();
		String Screen2 = TB2.getScreenShot("");
		if(sWorkshopsText.contains("WORKSHOP MATERIAL")) {
			ExtentReport.test.log(LogStatus.PASS, "Workshops Page Loaded Successfully"+ExtentReport.test.addScreenCapture(Screen2));
		}else {
			ExtentReport.test.log(LogStatus.FAIL, "Workshops Kata Page not Loaded Successfully"+ExtentReport.test.addScreenCapture(Screen2));
		}
		List<WebElement> multipleelement2 =TestBase.getWebElements("AllWorkshopElement");
		System.out.println(multipleelement2.size());
		for(WebElement e : multipleelement2) {
		  System.out.println(e.getText());
		  ExtentReport.test.log(LogStatus.PASS,e.getText());
		}		
		}

	}


