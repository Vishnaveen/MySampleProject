package automationprecondition;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import automationprecondition.AppConfig;


public class TestBase {
	public static String workingdir=System.getProperty("user.dir");
	public static WebDriver driver;
	public static Properties prop1;
	public static FileInputStream fis1;
	public static SimpleDateFormat sdf1;
	public static String Locatorfile=workingdir+"/configfiles/Locators.properties";
	
public static void getBrowser() throws IOException {	
	if(AppConfig.getBrowser().equals("Firefox")) {
		System.setProperty("WebDriver.gecko.driver", AppConfig.workingdir+"/geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
	}
	if(AppConfig.getBrowser().equals("Headless")) {
		System.setProperty("WebDriver.gecko.driver", AppConfig.workingdir+"/geckodriver.exe");
		FirefoxOptions options = new FirefoxOptions();
		options.setHeadless(true);
		driver = new FirefoxDriver(options);
		driver.manage().window().maximize();
	}
	if(AppConfig.getBrowser().equals("Chrome")) {
		System.setProperty("webdriver.chrome.driver", AppConfig.workingdir +"/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
}

public static void loadPropertiesFile() throws IOException
{
	prop1= new Properties();
	File file = new File(Locatorfile);
	fis1 = new FileInputStream(file);
	prop1.load(fis1);
}

public static WebElement getLocator(String locator) throws Exception
{
	if(locator.contains("//"))
		return driver.findElement(By.xpath(locator));
		else if(locator.contains(""))
			return driver.findElement(By.linkText(locator));
		else throw new Exception("Unknown Locator type "+locator);	
}

public static WebElement getWebElement(String elementName) throws Exception
{
	return getLocator(prop1.getProperty(elementName));
}

public static List<WebElement> getLocators(String locators) throws Exception
{
	if(locators.contains("//"))
		return driver.findElements(By.xpath(locators));
		else if(locators.contains(""))
			return driver.findElements(By.linkText(locators));
		else throw new Exception("Unknown Locator type "+locators);
}

public static List<WebElement> getWebElements(String elementNames) throws Exception
{
	return getLocators(prop1.getProperty(elementNames));
}

public String getScreenShot(String imageName) throws IOException
{
	String Base64StringofScreenshot="";
    File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    byte[] fileContent = FileUtils.readFileToByteArray(src);
    Base64StringofScreenshot = "data:image/png;base64,"+Base64.getEncoder().encodeToString(fileContent);
    return Base64StringofScreenshot;
}

}