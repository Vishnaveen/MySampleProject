package automationprecondition;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ITestResult;
import com.relevantcodes.extentreports.LogStatus;

import automationprecondition.AppConfig;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class ExtentReport {
	public static ExtentReports extent;
	public static ExtentTest test;
	public static SimpleDateFormat sdf;
	public static String workingdir1=System.getProperty("user.dir");

		static
		{
			sdf = new SimpleDateFormat("dd-MM-YYYY&&hh-mm-SS-SSS");
			System.out.println(sdf.format(new Date()));			
			 try {
				extent = new ExtentReports(AppConfig.getReportPath()+sdf.format(new Date())+".html",false);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
		public void getResult(ITestResult result) throws IOException 
		{
			
			if (result.getStatus() == ITestResult.SUCCESS) {
				test.log(LogStatus.PASS, result.getName() + " Test Passed Successfully");}
			else if (result.getStatus() == ITestResult.SKIP) {
				test.log(LogStatus.SKIP, result.getName() + " Test is skipped due to: " + result.getThrowable());}
			else if (result.getStatus() == ITestResult.FAILURE) {
				test.log(LogStatus.FAIL, result.getName() + " Test is failed" + result.getThrowable());
			}
			else if (result.getStatus() == ITestResult.STARTED) {
				test.log(LogStatus.INFO, result.getName() + " Test has Started");
				}
		}


		

}
