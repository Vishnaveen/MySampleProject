package automationprecondition;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class AppConfig {

	public static String workingdir=System.getProperty("user.dir");
	public static String configfile=workingdir+"/configfiles/Application.properties";
	
	public static Properties GetFileinputstream() throws IOException {
		File file=new File(configfile);
  		FileInputStream fileInput=null;
  		fileInput=new FileInputStream(file);
  		Properties prop=new Properties();
  		prop.load(fileInput);
  		return prop;
	}	
	
	public static String getBrowser() throws IOException {

	    return GetFileinputstream().getProperty("Browser");
  		
	}
	
	public static String getURL() throws IOException {

  		return GetFileinputstream().getProperty("URL");
  		
	}
	public static String getFirstnumber() throws IOException {
		
		return GetFileinputstream().getProperty("FirstNumber");
  		
	}
	public static String getSecondNumber() throws IOException {

		return GetFileinputstream().getProperty("SecondNumber");
  		
	}
	public static String getReportPath() throws IOException
	{
		try
		{
			return GetFileinputstream().getProperty("ScreenshotLocation");
		}
		catch(Exception e){ e.printStackTrace();}
		return null;
	}
}
